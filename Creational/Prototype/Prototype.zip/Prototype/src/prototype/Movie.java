/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author Stephen
 */
public class Movie extends Item {
    private String runtime;
    
    public String getRuntime(){
        return runtime;
    }
    
    public void setRuntime(String runtime){
        this.runtime = runtime;
    }
}
